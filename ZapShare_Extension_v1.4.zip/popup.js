document.addEventListener('DOMContentLoaded', function () {
    const codeInput = document.getElementById('code-input');
    // Auto-focus the input
    codeInput.focus();

    const btnReceive = document.getElementById('btn-receive');
    const btnSend = document.getElementById('btn-send');
    const errorMsg = document.getElementById('error-msg');

    function getIpFromCode(code) {
        if (!code) return null;
        code = code.trim().toUpperCase();

        // Check if user entered an IP directly just in case
        if (/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(code)) {
            return code;
        }

        // Basic validation: alpha numeric, max 8 chars
        if (!/^[0-9A-Z]{1,8}$/.test(code)) return null;

        const val = parseInt(code, 36);
        if (isNaN(val)) return null;

        // Decode IP from integer
        // Use unsigned right shift (>>>) to handle 32-bit integers correctly
        const p0 = (val >>> 24) & 255;
        const p1 = (val >>> 16) & 255;
        const p2 = (val >>> 8) & 255;
        const p3 = val & 255;

        return `${p0}.${p1}.${p2}.${p3}`;
    }

    function handleConnect(port) {
        const code = codeInput.value;
        const ip = getIpFromCode(code);

        if (ip) {
            errorMsg.classList.remove('visible');
            const url = `http://${ip}:${port}`;
            chrome.tabs.create({ url: url });
        } else {
            errorMsg.classList.add('visible');
            shakeInput();
        }
    }

    btnReceive.addEventListener('click', () => handleConnect(8080));
    btnSend.addEventListener('click', () => handleConnect(8090));

    function shakeInput() {
        codeInput.animate([
            { transform: 'translate(0)' },
            { transform: 'translate(-5px)' },
            { transform: 'translate(5px)' },
            { transform: 'translate(-5px)' },
            { transform: 'translate(0)' }
        ], {
            duration: 200,
            iterations: 1
        });
    }

    // Allow Enter key to trigger Receive (default)
    codeInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleConnect(8080);
        }
    });
});
