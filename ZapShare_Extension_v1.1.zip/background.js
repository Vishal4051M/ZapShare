// Background service worker (dummy for now, but good practice for MV3)
chrome.runtime.onInstalled.addListener(() => {
    console.log("ZapShare Connector Installed");
});
